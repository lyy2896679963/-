# -*- coding: utf-8 -*-
from tieba.tieba import TiebaCheckIn
