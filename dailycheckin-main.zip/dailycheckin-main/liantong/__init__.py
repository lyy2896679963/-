# -*- coding: utf-8 -*-
from liantong.liantong import LianTongCheckIn
