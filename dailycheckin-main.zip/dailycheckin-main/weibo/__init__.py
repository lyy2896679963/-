# -*- coding: utf-8 -*-
from weibo.weibo import WeiBoCheckIn
