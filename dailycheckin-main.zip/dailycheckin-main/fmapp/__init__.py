# -*- coding: utf-8 -*-
from fmapp.fmapp import FMAPPCheckIn
