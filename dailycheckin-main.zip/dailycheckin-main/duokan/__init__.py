# -*- coding: utf-8 -*-
from duokan.duokan import DuoKanCheckIn
