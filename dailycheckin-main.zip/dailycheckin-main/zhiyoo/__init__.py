# -*- coding: utf-8 -*-
from zhiyoo.zhiyoo import ZhiyooCheckIn
