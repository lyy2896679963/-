# -*- coding: utf-8 -*-
from bilibili.bilibili import BiliBiliCheckIn
