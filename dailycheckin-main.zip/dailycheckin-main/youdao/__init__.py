# -*- coding: utf-8 -*-
from youdao.youdao import YouDaoCheckIn
