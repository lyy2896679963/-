# -*- coding: utf-8 -*-
from motto.motto import Motto
