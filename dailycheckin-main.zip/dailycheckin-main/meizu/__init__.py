# -*- coding: utf-8 -*-
from meizu.meizu import MeizuCheckIn
