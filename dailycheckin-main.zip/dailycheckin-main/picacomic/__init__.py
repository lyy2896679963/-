# -*- coding: utf-8 -*-
from picacomic.picacomic import PicacomicCheckIn
