# -*- coding: utf-8 -*-
from smzdm.smzdm import SmzdmCheckIn
