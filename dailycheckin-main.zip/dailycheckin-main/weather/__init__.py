# -*- coding: utf-8 -*-
from weather.weather import Weather
