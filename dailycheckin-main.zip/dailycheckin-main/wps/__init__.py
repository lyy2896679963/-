# -*- coding: utf-8 -*-
from wps.wps import WPSCheckIn
