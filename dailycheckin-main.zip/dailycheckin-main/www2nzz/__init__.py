# -*- coding: utf-8 -*-
from www2nzz.www2nzz import WWW2nzzCheckIn
