# -*- coding: utf-8 -*-
from baidu_url_submit.baidu_url_submit import BaiduUrlSubmit
